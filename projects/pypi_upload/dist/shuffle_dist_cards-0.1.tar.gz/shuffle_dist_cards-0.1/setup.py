from setuptools import setup

setup(name='shuffle_dist_cards',
      version='0.1',
      description='Shuffle and distribute cards ',
      author='Ajinkya Joshi',
      author_email='ajinkya.dj92@gmail.com',
      packages=['shuffle_dist_cards'],
      zip_safe=False)